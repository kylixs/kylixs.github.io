import * as ARIAUtils from './ARIAUtils.js';

export {ARIAUtils};