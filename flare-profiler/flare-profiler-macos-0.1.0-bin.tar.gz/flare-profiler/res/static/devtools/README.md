devtools  
Extract flamechart from chrome-devtools-frontend  

Run:
1) Browser open flare-client/simpleui/devtools/flamechart.html
2) F12, Open console  
  exec cmd: load_profile()
  

